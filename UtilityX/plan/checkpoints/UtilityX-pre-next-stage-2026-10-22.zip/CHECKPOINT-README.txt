UtilityX rollback checkpoint
Captured: 2026-10-22 (Asia/Kolkata)
Git HEAD at capture: 214e71f
Current app config: noRedirectionBitmap=true, visible=true.
Includes: UtilityX/Main source, frontend dist, package and Cargo lockfiles, UtilityX/plan notes, and authoritative target/debug/winutilx-task1.exe.
Excludes: ignored generated node_modules, Cargo target build cache, and stale copied Main/WinUtilX.exe. Restore dependencies with npm ci before rebuilding if needed.
Restore: extract this archive over the UTool workspace to restore captured files. Later files added after this checkpoint may need separate removal after review.
